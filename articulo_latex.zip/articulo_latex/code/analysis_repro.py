# -*- coding: utf-8 -*-
"""Reproducción de gráficos y tablas del artículo (datos agregados).

Uso:
  python analysis_repro.py --base_dir .
"""

import argparse
import os

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency


def save_bar(df, xcol, ycol, title, xlabel, ylabel, outpath, rotate=45):
    plt.figure(figsize=(8, 4.8))
    plt.bar(df[xcol], df[ycol])
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if rotate:
        plt.xticks(rotation=rotate, ha="right")
    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close()


def chi_square(counts_2d: np.ndarray):
    chi2, p, dof, exp = chi2_contingency(counts_2d)
    n = counts_2d.sum()
    r, c = counts_2d.shape
    v = np.sqrt(chi2 / (n * min(r - 1, c - 1)))
    return chi2, p, dof, v


def main(base_dir: str):
    data_dir = os.path.join(base_dir, "data")
    fig_dir = os.path.join(base_dir, "figures_repro")
    tab_dir = os.path.join(base_dir, "tables_repro")
    os.makedirs(fig_dir, exist_ok=True)
    os.makedirs(tab_dir, exist_ok=True)

    sex = pd.read_csv(os.path.join(data_dir, "sex.csv"))
    education = pd.read_csv(os.path.join(data_dir, "education.csv"))
    zone = pd.read_csv(os.path.join(data_dir, "zone.csv"))
    age = pd.read_csv(os.path.join(data_dir, "age.csv"))
    problems = pd.read_csv(os.path.join(data_dir, "problems_top10_first.csv"))
    gov_eval_fields_malo = pd.read_csv(os.path.join(data_dir, "gov_eval_fields_malo.csv"))
    party_top10 = pd.read_csv(os.path.join(data_dir, "party_top10.csv"))
    candidate_top10 = pd.read_csv(os.path.join(data_dir, "candidate_top10.csv"))

    save_bar(
        age,
        "categoria",
        "pct",
        "Distribución de edad (n=4,111)",
        "Grupo de edad",
        "Proporción",
        os.path.join(fig_dir, "fig_age.png"),
        rotate=45,
    )
    save_bar(
        problems,
        "Problema (primer lugar)",
        "%",
        "Principales problemas (primer problema) – top 10",
        "",
        "Porcentaje",
        os.path.join(fig_dir, "fig_problems_first.png"),
        rotate=60,
    )
    save_bar(
        gov_eval_fields_malo,
        "Campo",
        "% Malo",
        'Evaluación negativa ("Malo") por campo',
        "",
        "Porcentaje",
        os.path.join(fig_dir, "fig_eval_malo_field.png"),
        rotate=45,
    )
    save_bar(
        party_top10,
        "Partido/agrupación",
        "%",
        "Preferencia partidaria (top 10)",
        "",
        "Porcentaje",
        os.path.join(fig_dir, "fig_party_top10.png"),
        rotate=60,
    )
    save_bar(
        candidate_top10,
        "Candidatura",
        "%",
        "Intención de voto (top 10)",
        "",
        "Porcentaje",
        os.path.join(fig_dir, "fig_candidate_top10.png"),
        rotate=60,
    )

    gov_eval_by_region = pd.read_csv(os.path.join(data_dir, "gov_eval_by_region.csv"))
    vote_certainty_by_region = pd.read_csv(os.path.join(data_dir, "vote_certainty_by_region.csv"))
    party_by_region = pd.read_csv(os.path.join(data_dir, "party_by_region.csv"))
    candidate_by_region = pd.read_csv(os.path.join(data_dir, "candidate_by_region.csv"))

    tests = []
    for name, df in [
        ("Evaluación general", gov_eval_by_region),
        ("Seguridad/indecisión de voto", vote_certainty_by_region),
        ("Preferencia partidaria", party_by_region),
        ("Intención de voto", candidate_by_region),
    ]:
        counts = df[["GAM", "NoGAM"]].to_numpy()
        chi2, p, dof, v = chi_square(counts)
        tests.append(
            {"Variable": name, "Chi2": round(chi2, 2), "gl": dof, "p": p, "V de Cramér": round(v, 3)}
        )
    tests_df = pd.DataFrame(tests)
    tests_df.to_csv(os.path.join(tab_dir, "tests_region.csv"), index=False, encoding="utf-8")

    # tablas LaTeX básicas
    for name, df in [("sex", sex), ("education", education), ("zone", zone), ("tests_region", tests_df)]:
        with open(os.path.join(tab_dir, f"{name}.tex"), "w", encoding="utf-8") as f:
            f.write(df.to_latex(index=False, escape=True))

    print("OK. Figuras en", fig_dir, "y tablas en", tab_dir)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_dir", default=".")
    args = ap.parse_args()
    main(args.base_dir)
