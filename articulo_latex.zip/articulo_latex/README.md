# Paquete reproducible – Artículo (LaTeX) y código (Colab)

## Estructura
- `main.tex`: manuscrito en LaTeX.
- `referencias.bib`: bibliografía en formato BibLaTeX (APA 7).
- `figures/`: figuras PNG usadas por el manuscrito.
- `tables/`: tablas en LaTeX (`\input{...}`).
- `data/`: datos agregados (CSV) utilizados para reproducir figuras/tablas.
- `code/`:
  - `code_colab.ipynb`: cuaderno listo para Google Colab.
  - `analysis_repro.py`: script equivalente.

## Compilación (LaTeX)
Recomendado con `latexmk` + `biber`:

```bash
latexmk -pdf -interaction=nonstopmode -shell-escape main.tex
```

Si no usa `latexmk`, ejecute:

```bash
pdflatex main.tex
biber main
pdflatex main.tex
pdflatex main.tex
```

## Reproducción en Google Colab
1. Suba el ZIP completo a Colab.
2. Descomprima en el entorno (p. ej. `!unzip articulo_latex.zip`).
3. Abra `code/code_colab.ipynb` y ejecute celdas.

> Nota: el cuaderno reproduce resultados con **datos agregados**. Para análisis multivariado o intervalos,
> se requieren microdatos.
